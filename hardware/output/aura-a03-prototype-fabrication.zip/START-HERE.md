# AURA A03 prototype fabrication package

Open **hardware/native/aura-a03.kicad_pro** in KiCad 10. The paired project,
portable libraries, manufacturing files, authored sources and audit evidence are included.

Read the [native project and manufacturing guide](hardware/native/README.md)
before using any fabrication or assembly files.

Verified native board SHA-256: `b9ec8ebf1a0afaa7563ed4838e145cebb4f14055f71e25b2dbcb0329b0180064`.

- Unconnected items: 0.
- Schematic/PCB parity findings: 0.
- ERC errors and warnings: 0.
- Bare-board DRC errors: 0.
- Unsuppressed assembly courtyard findings: **78**.

**Assembly review hold:** the courtyard findings remain visible. Assembly approval
and physical qualification are false. These are connected prototype fabrication
and review files; they do not establish a qualified assembled wearable.

The [engineering manifest](hardware/output/engineering-package-manifest.json)
binds every included source file to its byte size and SHA-256. The external archive
checksum report is intentionally not included inside the archive it describes.

Original source and project documentation: [Avinash1286/pendent](https://github.com/Avinash1286/pendent).
